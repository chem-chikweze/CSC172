/*
 * Referrence: https://youtu.be/OgJL8eh87PI
 */
public class BinarySearchTree<T extends Comparable<T>> implements BST {

	private static MyTreeNode root;
	
	public BinarySearchTree() {
		
	}
	
	public BinarySearchTree(MyTreeNode<T> root) {
		root = root;
		root.leftChild = root.rightChild = null;
		
	}
	
	public static void main(String[] args) {
	
		System.out.println("Name:Chukwubuikem Chikweze \nID: 31531764 \nLab Number: 51485\nThe Laboratory Output\n\n"
				+ "I first have this array which I transform into a tree by using a for each loop to insert each element to our tree"
				+ "\n{334,34,1,2, 12,53,61,69,24,23,90,35,51}\n");

		BinarySearchTree tree = new BinarySearchTree();
		
		int[] arr= {334,34,1,2, 12,53,61,69,24,23,90,35,51};
		//insert 
		for(int a:  arr) {
			tree.insert(a);
		}
		
		System.out.println("I print three times using three iterating types:\n");
		//preOrder, InOrder and PostOrder
		System.out.println("Print PreOrder");
		tree.printPreOrder();
		System.out.println();
		System.out.println("Print InOrder");
		tree.printInOrder();
		System.out.println();
		System.out.println("Print PostOrder");
		tree.printPostOrder();
		System.out.println();
		
		System.out.println("\nI look up the value 2 then delete it");
		// lookup and delete
		System.out.println("It prints true if it is there and false if it is not there after it is no longer there");
		System.out.println(tree.lookup(2));
		tree.delete(2);
		System.out.println(tree.lookup(2));

		tree.delete(tree.root.data);
//		tree.delete(12);
//		tree.delete(53);
		System.out.println("\nThere are three more lookups which all return false because I do not have any of those elements in the tree.");
		System.out.println(tree.lookup(6));
		System.out.println(tree.lookup(12));
		System.out.println(tree.lookup(53));

		
		
		//tree.printPreOrder();
		System.out.println();
		
		
		//tree.lookup(343);
		
	}

	@Override
	public void insert(Comparable x) {
		MyTreeNode nodeToAdd = new MyTreeNode(x);
		
		if(root == null)
			root = nodeToAdd;
		traverseAndAddNode(root, nodeToAdd);
	}
	
	private void traverseAndAddNode(MyTreeNode node, MyTreeNode nodeToAdd) {
		
		if( nodeToAdd.data.compareTo(node.data)< 0) {
			if(node.leftChild == null) {
				nodeToAdd.parent = node;
				node.leftChild = nodeToAdd;
			}
			traverseAndAddNode(node.leftChild, nodeToAdd);
		}
		else if( nodeToAdd.data.compareTo(node.data)> 0) {
			nodeToAdd.parent = node;
			if(node.rightChild == null) {
				node.rightChild = nodeToAdd;
			}
			traverseAndAddNode(node.rightChild, nodeToAdd);
		}
	}
	
	@Override
	public void delete(Comparable x) {
		///case1: node has no child
		// 2: node has one child
		// 3. node has two children
		
		MyTreeNode nodeToBeDeleted = find(x);
		
		if(nodeToBeDeleted != null) {
			
			if(nodeToBeDeleted.leftChild == null && nodeToBeDeleted.rightChild == null) {
				deleteCase1(nodeToBeDeleted);
			}
			else if(nodeToBeDeleted.leftChild != null && nodeToBeDeleted.rightChild != null) {
				//node has both children 
				deleteCase3(nodeToBeDeleted);
			}
			else if(nodeToBeDeleted.leftChild != null) {
				deleteCase2(nodeToBeDeleted);
			}
			else if(nodeToBeDeleted.rightChild != null) {
				deleteCase2(nodeToBeDeleted);
			}	
		}
		
	}
	MyTreeNode minNode;
	private void deleteCase1(MyTreeNode nodeToBeDeleted) {
		if(nodeToBeDeleted.parent.leftChild == nodeToBeDeleted)
			nodeToBeDeleted.parent.leftChild = null;
		else if(nodeToBeDeleted.parent.rightChild == nodeToBeDeleted)
			nodeToBeDeleted.parent.rightChild = null;
		
	}
	
	private void deleteCase2(MyTreeNode nodeToBeDeleted) {
		if(nodeToBeDeleted.parent == null) {
			root = minNode;
		}else {
			if(nodeToBeDeleted.parent.leftChild == nodeToBeDeleted) {
				if(nodeToBeDeleted.leftChild != null) {
					nodeToBeDeleted.parent.leftChild = nodeToBeDeleted.leftChild;
				}
				else if(nodeToBeDeleted.rightChild != null) {
					nodeToBeDeleted.parent.leftChild = nodeToBeDeleted.rightChild;
				}
			}
			else if(nodeToBeDeleted.parent.rightChild == nodeToBeDeleted) {
				if(nodeToBeDeleted.leftChild != null) {
					nodeToBeDeleted.parent.rightChild = nodeToBeDeleted.leftChild;
				}
				else if(nodeToBeDeleted.rightChild != null) {
					nodeToBeDeleted.parent.rightChild = nodeToBeDeleted.rightChild;
				}
			}
		}
		
		
	}
	
	private void deleteCase3(MyTreeNode nodeToBeDeleted) {
		
		minNode = minLeftTraversal(nodeToBeDeleted.rightChild);
		//what if minNode is deleteCase3? It can
		//t because we recursively go to the last value
		deleteCase2(minNode);
		
		minNode.parent = nodeToBeDeleted.parent;
		minNode.leftChild = nodeToBeDeleted.leftChild;
		minNode.rightChild = nodeToBeDeleted.rightChild;

		if(nodeToBeDeleted.parent == null) {
			root = minNode;
		}
		else {
			if(nodeToBeDeleted.parent.leftChild == nodeToBeDeleted) {
				nodeToBeDeleted.parent.leftChild = minNode;
			}
			else if(nodeToBeDeleted.parent.rightChild == nodeToBeDeleted) {
				nodeToBeDeleted.parent.rightChild = minNode;
			}
		}
		
	}
	
	private MyTreeNode minLeftTraversal(MyTreeNode node) {
		if(node.leftChild == null)
			return node;
		return minLeftTraversal(node.leftChild);
	}
	
	@Override
	public boolean lookup(Comparable x) {
		if(find(x) != null) return true;
		else
			return false;
	}

	public MyTreeNode find(Comparable x) {	
		if(root != null) {
			return findNode(root, new MyTreeNode(x));
		}
		
		return null;
		
	}
	
	public MyTreeNode findNode(MyTreeNode search, MyTreeNode node) {
		if(search == null) {
			return null;
		}
		if(search.data == node.data) {
			return search;
		}
		else {
			MyTreeNode returnNode = findNode(search.leftChild, node);
			
			if(returnNode == null) {
				returnNode = findNode(search.rightChild, node);
			}
			return returnNode;
		}
		
	}
	

	private static void preOrderTraversal(MyTreeNode node) {
		if(node == null) return;
		
		System.out.print(node.data + " ");

		if(node.leftChild != null) {
			preOrderTraversal(node.leftChild);
		}
		if(node.rightChild != null) {
			preOrderTraversal(node.rightChild);
		}
		
	}
	
	private static void inOrderTraversal(MyTreeNode node) {
		if(node == null) return;

		if(node.leftChild != null) {
			inOrderTraversal(node.leftChild);
		}
		
		System.out.print(node.data + " ");
		if(node.rightChild != null) {
			inOrderTraversal(node.rightChild);		
		}
		
	}
	
	private static void postOrderTraversal(MyTreeNode node) {
		if(node == null) return;

		if(node.leftChild != null) {
			postOrderTraversal(node.leftChild);
		}
		
		if(node.rightChild != null) {
			postOrderTraversal(node.rightChild);
			
		}
		System.out.print(node.data + " ");

	}
	
	@Override
	public void printPreOrder() {
		preOrderTraversal(root);
	}

	@Override
	public void printInOrder() {
		inOrderTraversal(root);
	}

	@Override
	public void printPostOrder() {
		postOrderTraversal(root);
	}
	
}