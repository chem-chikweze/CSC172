Name: Chukwubuikem Chikweze
ID: 31531764
Class: CSC172
Lab Number: 51485
Referrence:
https://www.cs.cmu.edu/~adamchik/15-121/lectures/Trees/trees.html
https://youtu.be/OgJL8eh87PI

Synopsis:
In the lab, the Abstract Data Types were implemented using several helper methods.
Other files included in this work include the output file and the class implementations.
OUTPUT.txt contains the output from the console.
BST.java contains the interface
BinarySearchTree.java contains java implementation of BST.java
MyTreeNode.java contains the implementation for a node.

Insert methods helper methods:
	traverseAndAddNode : 	which has two if statements that helps determine if the node being inserted should
				be inserted to the right or to the left.
Delete method helper methods:
	deleteCase1:	if the node does not have a child
	deleteCase2:	if the node has one child
	deleteCase3:	if the node has two children
deleteCase3 helper method:
	minLeftTraversal:	which gets the leftmost node of the from deleteCase2

printPreOrder 	helper method:	preOrderTraversal
printInOrder	helper method:	inOrderTraversal
printPostOrder	helper method:	postOrderTraversal