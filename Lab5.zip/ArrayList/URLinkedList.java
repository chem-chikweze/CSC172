package Lab5.ArrayList;

import java.util.Collection;
import java.util.Iterator;
class URLinkedList <E> implements URList<E> {
    private URNode<E> head;
    private URNode<E> tail;
    private int size;



    @Override
    public boolean add(E e) {
        URNode<E> temp = new URNode<E>(e, null, tail);
        if(tail != null) {tail.setNext (temp);}
        tail = temp;
        if(head == null) { head = temp;
            size++;
            return true;
        }
        else {
            return false;
        }


    }

    @Override
    public void add(int index, E element) {
        // TODO Auto-generated method stub
        URNode<E> temp = new URNode<E>(element, head, null);
        int i = 0;
        if (index<size) {

            while (index >= i ) {
                temp.setPrev (temp.setNext(temp));
                temp.setNext (temp.setPrev(temp));
                i++;
            }
            size++;
        }

    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean addAll(int index, Collection<? extends E> c) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void clear() {

        head.setPrev(head.setNext(null));
        tail.setNext(tail.setPrev(null));
        head.setPrev(tail.setNext(null));
        tail.setNext(head.setPrev(null));
    }

        @Override
        public boolean contains(Object o) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public boolean containsAll(Collection<?> c) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public E get(int index) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public int indexOf(Object o) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public boolean isEmpty() {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public Iterator<E> iterator() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public E remove(int index) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public boolean remove(Object o) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public boolean removeAll(Collection<?> c) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public E set(int index, E element) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public int size() {
            // TODO Auto-generated method stub
            return size;
        }

        @Override
        public URList<E> subList(int fromIndex, int toIndex) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public Object[] toArray() {
            // TODO Auto-generated method stub
            return null;
        }





    }