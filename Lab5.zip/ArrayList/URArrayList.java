package Lab5.ArrayList;
import java.util.*;


public class URArrayList<E extends URNode<E>> implements URList<E>, Iterable<E>{
    private URNode<E> e;
    private URNode<E> head;
    private URNode<E> tail;
    private int size;
    public int offset;
    protected transient int modCount = 0;
    Object[] elementData;

    ArrayList<E> arrayList;
    Iterator<E> arrayIter = URArrayList.iterator();
    private Object Collection;

    @Override   //DONE
    public boolean add(E e) {
        URNode<E> temp = new URNode(e, null, tail);
        if(head.next() == tail){    //if empty
            temp.setPrev(head);
            head.setNext(temp);
        }
        else{
            while(arrayIter.hasNext()) {
                head = head.next();
                if(head.next() == tail){
                    temp.setPrev(tail);
                    tail.setNext(temp);
                }
            }
        }
        size++;
        return true;
    }

    @Override
    public void add(int index, E element) {
        URNode<E> temp = new URNode(e, null, tail);
        ArrayList<E> list = new ArrayList<E>(size);
        Iterator<E> listItr = list.listIterator();
        int i = 0;
        if (index < size) {
            while (index >= i) {
                temp.setPrev(temp.setNext(temp));
                temp.setNext(temp.setPrev(temp));
                i++;
            }
            size++;
        }
    }


    @Override
    public boolean addAll(Collection<? extends E> c) {
            Object[] a = c.toArray();
            ++this.modCount;
            int numNew = a.length;
            if (numNew == 0) {
                return false;
            } else {
                Object[] elementData;
                int s;
                if (numNew > (elementData = this.elementData).length - (s = this.size)) {
                    elementData = this.grow(s + numNew);
                }

                System.arraycopy(a, 0, elementData, s, numNew);
                this.size = s + numNew;
                return true;
            }
    }


    @Override
    public boolean addAll(Collection<? extends E> c) {
        boolean result = false;
        Iterator<E> iterator = (Iterator<E>) c.iterator();
        while (iterator.hasNext()) {
            arrayList.add(iterator.next());
        }
        if (iterator.hasNext() == false) {
            result = true;
        }
        return result;
    }

    @Override
    public boolean addAll(int index, Collection<? extends E> c) {
        Object[] a = c.toArray();
        ++this.modCount;
        int numNew = a.length;
        if (numNew == 0) {
            return false;
        } else {
            Object[] elementData;
            int s;
            if (numNew > (elementData = this.elementData).length - (s = this.size)) {
                elementData = this.grow(s + numNew);
            }

            int numMoved = s - index;
            if (numMoved > 0) {
                System.arraycopy(elementData, index, elementData, index + numNew, numMoved);
            }

            System.arraycopy(a, 0, elementData, index, numNew);
            this.size = s + numNew;
            return true;
        }
    }

    @Override   //done
    public void clear() {
        Object[] es = this.elementData;
        int to = this.size;

        for(int i = this.size = 0; i < to; ++i) {
            es[i] = null;
        }


    }

    @Override   //done
    public boolean contains(Object o) {
        return this.indexOf(o) >= 0;
    }

    @Override   //done
    public boolean containsAll(Collection<?> c) {
        if(arrayList.equals(c))
            return true;
        return false;
    }

    @Override
    public E get(int index) {
        int i = 0;
        for(URNode<E> en: arrayList){
          //  if(en.prev().next().element() == index)
        };
        return null;
    }

    @Override
    public int indexOf(Object o) {

        int index = this.arrayList.indexOfRange(o, this.offset, this.offset + this.size);
        if (this.arrayList.modCount != this.modCount) {
            throw new ConcurrentModificationException();
        }
        return index >= 0 ? index - this.offset : -1;
    }

    @Override   //done
    public boolean isEmpty() {
        return this.size == 0;
    }

    @Override
    public static Iterator<E> iterator() {
        return null;
    }

    @Override   //done
    public E remove(int index) {
        if(index >=0 && index < size){
            for(int i = 0; i <index; i++){
                if(i == index-2){
                    this.e.next().setElement((E) this.e.next().next());
                    this.size = size -1;
                    return (E) e;
                }
                this.e.next();
            }

            return null;
        }else{
            throw new NullPointerException("the index is not in the ArrayList");
        }
    }

    @Override   //done
    public boolean remove(Object o) {
        while(!(arrayIter.equals(o)) && arrayIter.hasNext()){
            if(arrayIter.next() ==o){
                arrayIter.next().setElement(arrayIter.next().next().element());
                size = size-1;
                return true;
            }
        }
        return false;
    }

    @Override   //done
    public boolean removeAll(Collection<?> c) {
        while(arrayIter.hasNext()){
            arrayIter.next().setElement(null);
            size = size-1;
        }
        return false;
    }

    @Override   //done
    public E set(int index, E element) {
        Objects.checkIndex(index, this.size);
        E oldValue = this.e.element();
        this.e.setElement(element);
        return oldValue;
    }

    @Override //done
    public int size() {
        return this.size;
    }

    @Override
    public URList<E> subList(int fromIndex, int toIndex) {
        return null;
    }

    @Override   //done
    public Object[] toArray() {
        return Arrays.copyOf(new ArrayList[]{this.arrayList}, this.size);
    }

    // Increases the capacity of this ArrayList instance, if necessary,
// to ensure that it can hold at least the number of elements specified
// by the minimum capacity argument.
//////void ensureCapacity(int minCapacity)
// Returns the current capacity of the list
    int getCapacity() {
        return 0;
    }
}
