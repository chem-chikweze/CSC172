Name: Chukwubuikem Chikweze
Email: cchikwez@u.rochester.edu
Class: CSC172
Lab Number: 51485

*** Lab3: ****
