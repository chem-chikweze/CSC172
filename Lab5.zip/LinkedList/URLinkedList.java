package Lab5.LinkedList;
/*
public class URLinkedList {
    // Inserts the specified element at the beginning of this list.
    void addFirst(E e)
    // Appends the specified element to the end of this list.
    void addLast(E e)
// Retrieves, but does not remove, the first element of this list, or returns null if
this list is empty.
            E peekFirst()
// Retrieves, but does not remove, the last element of this list, or returns null if
this list is empty.
            E peekLast()
    // Retrieves and removes the first element of this list, or returns null if this list
    is empty.
    E pollFirst()
    // Retrieves and removes the last element of this list, or returns null if this list
    is empty.
    E pollLast()
}
*/