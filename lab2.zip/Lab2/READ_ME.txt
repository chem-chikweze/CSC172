Name: Chukwubuikem Chikweze
Email: cchikwez@u.rochester.edu
Class: CSC172
Lab Number: 51485

*** Lab2: ****
This lab is an exciting introduction to beautiful ways of problem solving using generics instead of non - generics.


