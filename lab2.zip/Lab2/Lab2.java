package Lab2;

/*
    Author: Chukwubuikem Chikweze
    Contact Email: cchikwez@u.rochester.edu


    References:
    Lecture 2 slides
    https://www.edureka.co/blog/array-of-objects-in-java/
 */
public class Lab2 {

    static Integer [] intArray = {1, 2, 3, 4, 5 };
    static Double [] doubArray = {1.1, 2.2, 3.3, 4.4};
    static Character [] charArray = {'H','E','L', 'L', 'O' };
    static String [] strArray = {"once", "upon", "a", "time" };

    private static Object[] JavaObjectArray= {intArray, doubArray, charArray, strArray};

    //printArrayNonGen with an Object Array as parameters
    public static <Object> void printArrayNonGen(Object[] JavaObjectArray){
        for(Object element: JavaObjectArray){
            System.out.println(element + ", ");
        }
        System.out.println();
    }

    // Four implementations of non-generic method for method overloading
    public static void printArray(Integer [] a) {
        //System.out.println("Non generic integer: ");
        System.out.print("{");
        for (Integer element : a)
            System.out.print(element + ", " );

        System.out.print("}");
        System.out.println();
    }
    public static void printArray(Double [] a) {
        //System.out.println("Non generic double: ");
        System.out.print("{");
        for (Double element : a)
            System.out.print(element + ", " );

        System.out.print("}");
        System.out.println();
    }
    public static void printArray(Character [] a) {
        //System.out.println("Non generic char: ");
        System.out.print("{");
        for (Character element : a)
            System.out.print(element + ", " );

        System.out.print("}");
        System.out.println();
    }
    public static void printArray(String [] a) {
        //System.out.println("Non generic string: ");
        System.out.print("{");
        for (String element : a)
            System.out.print(element + ", " );

        System.out.print("}");
        System.out.println();
    }

    // A generic that supports all four array types and maintains type safety
    private static <T> void printArrayGen(T[] type) {
        //System.out.println("Generic: ");
        System.out.print("{");
        for (T element : type) {
            System.out.print(element + ", " );
        }
        System.out.println("}");
    }


    // Comparable non-generic method that returns the maximum value
    public static Comparable getMax(Comparable [] anArray){
        //System.out.println("getMax");
        if(anArray.length == 1)
            return anArray[0];

        Comparable largest = anArray[0];
        for(int i = 0; i< anArray.length; i++){
            if(anArray[i].compareTo(largest) > 0 ){
                largest = anArray[i];
            }
        }
        //System.out.println("getMax has maximum value "+ largest );
        System.out.println(largest);
        return largest;
    }
    public static <T extends Comparable<? super T>> T  getMaxGen(T[] arr){
        //System.out.println("getMaxGen");
        int maxIndex = 0 ;
        for (int i = 1; i < arr.length;i++)
            if ( arr[i].compareTo(arr[maxIndex]) > 0 )
                maxIndex = i;
        //System.out.println("getMaxGen has maximum value "+ arr[maxIndex] + " index "+ maxIndex);
        System.out.println(arr[maxIndex]);
        return arr[maxIndex];
    }

    public static void main(String args[]){
        printArray(intArray);
        printArray(doubArray);
        printArray(charArray);
        printArray(strArray);

        printArrayGen(intArray);
        printArrayGen(doubArray);
        printArrayGen(charArray);
        printArrayGen(strArray);

        getMax(intArray);
        getMax(doubArray);
        getMax(charArray);
        getMax(strArray);

        getMaxGen(intArray);
        getMaxGen(doubArray);
        getMaxGen(charArray);
        getMaxGen(strArray);

    }

}
