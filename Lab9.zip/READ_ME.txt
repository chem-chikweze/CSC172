Name: Chukwubuikem Chikweze
ID: 31531764
Class: CSC172
Lab Number: 51485

*** Lab 9: ****
Contents:
Heap.java	An interface that contains the insert(), isEmpty(), size() and deleteMin() declarations
myHeap.java 	A java file that contains the implementation of the above methods as well as:
		doubleCap() : 
			A method that increases the capacity of the heap by a 2 times when it is about to overflow
		Three Constructors:
			One that assigns a default capacity
			The second allows specification of capacity
			The third builds a heap using an array in its parameter.
		bubbleUp():
			It is a helper method for the insert() function and it helps to move up a new entry up the heap.
		bubbleDown():
			It is used a helper method for deleteMin() and it brings down a value from heap[1] to it's correct position in the heap
		heapify():
			It is a helper function from the third constructor. Using an array, it builds a heap from scratch.
		printHeap():
			It prints out the elements in the heap.