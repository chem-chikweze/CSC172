/*
 * Name: Chukwubuikem Chikweze
 * ID: 31531764
 * Lab Number: 51485
 * References:
 * 	https://www.geeksforgeeks.org/building-heap-from-array/
 * 	https://www.cs.cmu.edu/~adamchik/15-121/lectures/Binary%20Heaps/code/Heap.java
 * 
 */

public class myHeap<T extends Comparable<T>> {	
	T [] heap;
	private int size;
	private int capacity = 10;
	
	//Constructor with default capacity
	public myHeap(){
		size = 0;
		heap = (T[]) new Comparable[capacity];
		
	}
	
	//Constructor with capacity
	public myHeap(int capacity1){
		capacity = capacity1;
		size = 0;
		heap = (T[]) new Comparable[capacity];
		
	}
		
	//Constructor array to heap
	public myHeap(T[] array){
		size = array.length;
	    heap = (T[]) new Comparable[size +1];  
	    System.arraycopy(array, 0, heap, 1, size);
	    heapify(heap);
	    capacity = size;
	    
	}
	
	//builds heap from array
	public void heapify(T[] heap) {
		for(int k = 1; k < heap.length; k++) { //starts from the middle and bubbles down 
	    	//elements up to the first.
	    	bubbleUp(heap[k], k);
	    }
	}
	
	private void bubbleDown(int k) {
		T temp = heap[k];
		int child;
	
		//skips through the array on speed 2 and 
		//continues as far as 2*k is <= size; 
		//it increases by making the next starting 
		//point of k to become 2*k
		for(; 2*k <= size; k = child ) {
			child = 2*k;
			//compares the values of child and child++. As this is a min heap,
			//it uses the child or child+1 with higher value
			if(child != size && heap[child].compareTo(heap[child+1]) > 0) child++;
			
			//checks tmp and child. if tmp (i.e heap[k] is bigger, we change it's value to 
			//that of heap[child]
			if(temp.compareTo(heap[child]) > 0) heap[k] = heap[child];
			else 
				//stop when heap[k] is less than chosen heap[child]
				break;
			
		}
		
		heap[k] = temp;
	}
	
	public int size() {
		return size;
	}
	
	public boolean isEmpty() {	
		for(int i = 0; i < heap.length; i++) {
			if(heap[i] != null)
				return false;
		}
		
		return true;
	}
	
	public  void insert(Comparable t) {		
		if(size == capacity-1) doubleCap();
		int pos = ++size; //helps us  a new node at bottom leftmost position of the tree
		bubbleUp(t, pos);
	}
	
	private void doubleCap() {		
		T [] old = heap;
		capacity *= 2;
	    heap = ((T[]) new Comparable[capacity]);
	    System.arraycopy(old, 1, heap, 1, size);
	    
	}

	public void bubbleUp(Comparable t, int pos) {
		if(size == capacity - 1) doubleCap();
		for( ;pos > 1 && t.compareTo(heap[pos/2]) < 0; pos = pos/2) {
			heap[pos] = heap[pos /2];
		}
		
		if(size == capacity - 1) doubleCap();
		heap[pos] = (T) t;	
		
	}
	
	public T deleteMin() throws RuntimeException {
		if(size == 0) throw new RuntimeException();
		T min = heap[1];
		heap[1] = heap[size--];
		T[] old = heap;
	    heap = ((T[]) new Comparable[old.length]);
	    System.arraycopy(old, 1, heap, 1, size);
		bubbleDown(1);
		return min;
		
	}
	
	public void printHeap() {
		for(Object x : heap) {
			if(x == null) continue;
			System.out.print(x+ " ");
		}
		
	}

	public static void main(String[] args) {	
		// test to test: constructor: isEmpty : size
		myHeap<Integer> newHeap = new myHeap(3);
		Integer a  = 7;
		Integer b  = 9;
		Integer c  = 1;
		Integer d  = 5;
		Integer e  = 3;
		Integer f  = 74;
		Integer g  = 67;
		Integer h  = 34;
		Integer i  = 45;
		Integer j  = 30;
		Integer k  = 6;
		Integer l  = 8;
		
		newHeap.insert(a);newHeap.insert(b);newHeap.insert(c);newHeap.insert(d);
		newHeap.insert(e);newHeap.insert(f);newHeap.insert(g);newHeap.insert(h);
		newHeap.insert(i);newHeap.insert(j);newHeap.insert(k);newHeap.insert(l);
		newHeap.insert(a);newHeap.insert(b);newHeap.insert(c);newHeap.insert(d);
		newHeap.insert(e);newHeap.insert(f);newHeap.insert(g);newHeap.insert(h);
		newHeap.insert(i);newHeap.insert(j);newHeap.insert(k);newHeap.insert(l);
		newHeap.insert(a);newHeap.insert(b);newHeap.insert(c);newHeap.insert(d);
		newHeap.insert(e);newHeap.insert(f);newHeap.insert(g);newHeap.insert(h);
		newHeap.insert(i);newHeap.insert(j);newHeap.insert(k);newHeap.insert(l);
		
		//first heap
		newHeap.printHeap();
		int n = newHeap.deleteMin();
		System.out.println();
		newHeap.printHeap();
		System.out.println("\nDeleted value is "+ n); //delete method
		System.out.println();

		System.out.println("Size of heap is "+ newHeap.size());
		System.out.println("Is the heap empty? "+ newHeap.isEmpty());	
		
		//random heap
		System.out.println();
		System.out.println("Next: ");
		System.out.println("The random heap: ");
		int capacity = (int) Math.ceil(Math.random()*1000);
//		System.out.println("cap is : "+capacity);
		Integer[] ranHeapArray = new Integer[capacity];
		
		//creating random contents
		int counter = 0;
		while( counter < capacity) {
			ranHeapArray[counter] = (int) Math.round(Math.random()* 100);
			counter++;
		}
		//for(int i1 = 0;i1 < capacity; i1++) System.out.print(ranHeapArray[i1]+" ");
		myHeap<Integer> randomHeap = new myHeap(ranHeapArray);
		randomHeap.printHeap();
		
		int newDel = (int) randomHeap.deleteMin();
		System.out.println();
		randomHeap.printHeap();
		System.out.println("\nDeleted value is "+ newDel);
		randomHeap.insert(a);
		randomHeap.insert(c);
		randomHeap.insert(d);
		randomHeap.insert(h);

		System.out.println();
		System.out.println("Size of heap is "+ randomHeap.size());
		System.out.println("Is the heap empty? "+ randomHeap.isEmpty());
		System.out.println();
		System.out.println("Inserting new elements into the heap:");
		randomHeap.printHeap();
		System.out.println("\nElements inserted are: "+a+", "+c+", "+d+", and "+h);
	}
}
 