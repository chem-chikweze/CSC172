package Lab3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class Lab3Task3 {
    private static ArrayList <Integer> array;
    public static ArrayList<Integer> getArray() {
        return array;
    }
    public static void setArray(ArrayList<Integer> arr) { array = arr; }

    public static void printArrayListBasicLoop(ArrayList<Integer> arrayList){
        for(int i = 0; i< arrayList.size(); i++){
            System.out.print(arrayList.get(i) + "\t");
        }
        System.out.println();
    }
    public static void printArrayListBasicWhileLoop(ArrayList<Integer> arrayList){
        int i=0;
        while(i < arrayList.size()){
            System.out.print(arrayList.get(i) + "\t");
            i = i+1;
        }
        System.out.println();
    }
    public static void printArrayListEnhancedLoop(ArrayList<Integer> arrayList){
        for(Integer i : arrayList){
            System.out.print(i + "\t");
        }
        System.out.println();
    }
    public static void printArrayListForLoopListIterator(ArrayList<Integer> arrayList){
        Iterator<Integer> integersIterator = arrayList.iterator();
        for (Iterator<Integer> it = integersIterator; it.hasNext(); ) {
            System.out.print(it.next()+ "\t");
        }
        System.out.println();
    }
    public static void printArrayListWhileLoopListIterator(ArrayList<Integer> arrayList){
        Iterator<Integer> integerIterator = arrayList.iterator();
        while(integerIterator.hasNext()){
            System.out.print(integerIterator.next() + "\t");
        }
        System.out.println();
    }



    public static void main (String args[]){
        ArrayList<Integer> list = new ArrayList<Integer>();
        list.addAll(Arrays.asList(1, 4, 5, 0));

        setArray(list);
        printArrayListBasicLoop(getArray());
        printArrayListBasicWhileLoop(getArray());
        printArrayListEnhancedLoop(getArray());
        printArrayListForLoopListIterator(getArray());
        printArrayListWhileLoopListIterator(getArray());

    }
}
