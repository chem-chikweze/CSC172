package Lab3;

import java.util.ArrayList;
import java.util.Arrays;

public class Lab3Task2 {
    private static int[][] arrayQuad;
    private static ArrayList<ArrayList<Integer>> arrayList = new ArrayList<ArrayList<Integer>>();

    public static int[][] getArrayQuad() {
        return arrayQuad;
    }
    public static ArrayList<ArrayList<Integer>> getArrayList() { return arrayList; }
    public static void setArrayQuad(int[][] arrayQ) {
        arrayQuad = arrayQ;
    }
    private static void setArrayList(ArrayList<ArrayList<Integer>> list) { arrayList = list; }


    //2
    public static void runningSum2DArray(int[][] array, int dir){
        int sum;
        switch (dir){
            case 1:
            {
                sum = 0;
                int[] arrayTemp = new int[4];
                for(int i = 0; i <array.length; i++){
                    for(int x = array[i].length-1; x >= 0; x--){
                        sum += array[i][x];
                    }
                    for(int x = 0; x < array[i].length; x++){
                        System.out.print(sum + "\t");
                        sum = sum - array[i][x];
                    }
                    sum = 0;
                    System.out.println();
                }
            }
            System.out.println("done with 1");

            break;
            case 2:
            {
                sum=0;
                for(int[] row: array){
                    for(int x: row){
                        sum += x;
                        System.out.print(sum + "\t ");
                    }
                    sum = 0;
                    System.out.println();
                }
            }
            System.out.println("done with 2");
            break;
            case 3:
            {
                sum = 0;
                int a, b,c,d;
                a=b=c=d=0;
                int[] arrayTemp = {a,b,c,d};
                for(int i = 0; i< array.length; i++){
                    for(int j = 0; j < array.length; j++){
                        arrayTemp[j] = arrayTemp[j] + array[i][j];
                        System.out.print(arrayTemp[j] + "\t");
                    }
                    System.out.println();
                }
            }
            System.out.println("done with 3");
            break;
            case 4:
            {
                sum = 0;
                int a, b,c,d;
                a=b=c=d=0;
                int[] arrayTemp = {a,b,c,d};
                for(int i = array.length-1; i >= 0 ; i--){
                    for(int x = 0; x <= array[i].length-1; x++){
                        arrayTemp[x] += array[i][x];
                    }

                    sum = 0;
                }

                for(int i = 0; i < array.length; i++){
                    for(int j = 0; j < array.length; j++){
                        System.out.print(arrayTemp[j] + "\t");
                        arrayTemp[j] = arrayTemp[j] - array[i][j];
                    }

                    System.out.println();
                }

            }
            System.out.println("done with 4");

            break;
            default:
                System.out.println("Invalid direction.");
        }

    }
    private static ArrayList<ArrayList<Integer>> runningSum2DArrayList(ArrayList<ArrayList<Integer>> arrayList, int dir) {
        int sum;
        switch (dir){
            case 1:
            {
                sum = 0;
                int[] arrayTemp = new int[4];
                for(int i = 0; i <arrayList.size(); i++){
                    for(int x = arrayList.get(i).size()-1; x >= 0; x--){
                        sum += arrayList.get(i).get(x);
                    }
                    for(int x = 0; x < arrayList.get(i).size(); x++){
                        System.out.print(sum + "\t");
                        sum = sum - arrayList.get(i).get(x);
                    }
                    sum = 0;
                    System.out.println();
                }
            }
            System.out.println("Array List done with 1");

            break;
            case 2:
            {
                sum=0;
                for( int i =0; i < arrayList.size(); i++){
                    for(int x = 0; x < arrayList.get(i).size(); x++){
                        sum += arrayList.get(i).get(x);
                        System.out.print(sum + "\t ");
                    }
                    sum = 0;
                    System.out.println();
                }
            }
            System.out.println("done with 2");
            break;
            case 3:
            {
                sum = 0;
                int a, b,c,d;
                a=b=c=d=0;
                int[] arrayTemp = {a,b,c,d};
                for(int i = arrayList.size()-1; i >= 0 ; i--){
                    for(int x = 0; x <= arrayList.get(i).size()-1; x++){
                        arrayTemp[x] += arrayList.get(i).get(x);
                    }

                    sum = 0;
                }

                for(int i = 0; i < arrayList.size(); i++){
                    for(int j = 0; j < arrayList.size(); j++){
                        System.out.print(arrayTemp[j] + "\t");
                        arrayTemp[j] = arrayTemp[j] - arrayList.get(i).get(j);
                    }

                    System.out.println();
                }

            }
            System.out.println("Array List  with 3");
            break;
            case 4:
            {
                sum = 0;
                int a, b,c,d;
                a=b=c=d=0;
                int[] arrayTemp = {a,b,c,d};
                for(int i = 0; i< arrayList.size(); i++){
                    for(int j = 0; j < arrayList.size(); j++){
                        arrayTemp[j] = arrayTemp[j] + arrayList.get(i).get(j);
                        System.out.print(arrayTemp[j] + "\t");
                    }
                    System.out.println();
                }

            }
            System.out.println("Array List done with 4");
            break;
            default:
                System.out.println("Invalid direction.");
        }
        return null;
    }
    public static void main (String args[]){
        int[][] array = {{10, 15, 30, 40},{15, 5, 8, 2}, {20, 2, 4, 2},{1, 4, 5, 0}};

        ArrayList<ArrayList<Integer>> list = new ArrayList<ArrayList<Integer>>(4);
        list.add(new ArrayList<Integer>(Arrays.asList(10, 15, 30, 40)));
        list.add(new ArrayList<Integer>(Arrays.asList(15, 5, 8, 2)));
        list.add(new ArrayList<Integer>(Arrays.asList(20, 2, 4, 2)));
        list.add(new ArrayList<Integer>(Arrays.asList(1, 4, 5, 0)));

        setArrayQuad(array);
        setArrayList(list);
        runningSum2DArray(array,1);
        runningSum2DArray(array,2);
        runningSum2DArray(array,3);
        runningSum2DArray(array,4);

    }
}
