Name: Chukwubuikem Chikweze
Email: cchikwez@u.rochester.edu
Class: CSC172
Lab Number: 51485

*** Lab3: ****
I loved this lab!

I ended up figuring out interesting ways to implement the "runningSum2DArrayList" method. It was fun.

The lab is divided into three parts

    1. Lab3Task1.java that solves the print2DArray() and print2DArrayList() methods
    2. Lab3Task2.java that solves the runningSum2DArray() and runningSum2DArrayList() methods
    3. Lab3Task3.java that solves the printing events for an arrayList.
        - printArrayListBasicLoop() that prints using a basic for loop
        - printArrayListBasicWhileLoop() that prints using a While loop
        - printArrayListEnhancedLoop() that uses a foreach loop to print the elements of the array list
        - printArrayListForLoopListIterator() that uses a for each loop with an iterator to do the printing
        - printArrayListWhileLoopListIterator() that uses a while loop and an iterator to print



