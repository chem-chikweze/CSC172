package Lab3;

import java.util.ArrayList;
import java.util.Arrays;

public class Lab3Task1 {

    private static int[][] arrayQuad;
    private static ArrayList<ArrayList<Integer>> arrayList = new ArrayList<ArrayList<Integer>>();

    public static int[][] getArrayQuad() {
        return arrayQuad;
    }
    public static ArrayList<ArrayList<Integer>> getArrayList() { return arrayList; }
    public static void setArrayQuad(int[][] arrayQ) {
        arrayQuad = arrayQ;
    }
    private static void setArrayList(ArrayList<ArrayList<Integer>> list) { arrayList = list; }


    public static void print2DArray(int[][] array){
        for(int[] row: array){
            for(int x: row){
                System.out.print(x + "\t ");
            }
            System.out.println();
        }
    }

    public static void print2DList(ArrayList<ArrayList<Integer>> list){
        for(ArrayList<Integer> row : list){
            for(int x : row){
                System.out.print(x + "\t");
            }
            System.out.println();
        }
    }



    public static void main(String args[]){
        int[][] array = {{10, 15, 30, 40},{15, 5, 8, 2}, {20, 2, 4, 2},{1, 4, 5, 0}};

        ArrayList<ArrayList<Integer>> list = new ArrayList<ArrayList<Integer>>(4);
        list.add(new ArrayList<Integer>(Arrays.asList(10, 15, 30, 40)));
        list.add(new ArrayList<Integer>(Arrays.asList(15, 5, 8, 2)));
        list.add(new ArrayList<Integer>(Arrays.asList(20, 2, 4, 2)));
        list.add(new ArrayList<Integer>(Arrays.asList(1, 4, 5, 0)));

        setArrayQuad(array);
        setArrayList(list);
        print2DArray(getArrayQuad());
        System.out.println();
        print2DList(getArrayList());
    }
}


