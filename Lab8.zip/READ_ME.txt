Name: Chukwubuikem Chikweze
ID: 31531764
Class: CSC172
Lab Number: 51485

*** Lab 8: ****
The set of values from my terminal is in the OUTPUT.txt file
Lab8.pdf contains my graphing of the computation time and some other observations.
SortTest.java contains the code.
OUTPUT.txt contains values of my sort program copied from the command line.
