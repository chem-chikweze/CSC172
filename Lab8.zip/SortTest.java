/**
 * Name: Chukwubuikem Chikweze
 * ID: 31531764
 * 
 * References: 
 * https://www.thejavaprogrammer.com/quick-sort-java/
 * http://thomas.baudel.name/Visualisation/VisuTri/Docs/shellsort.pdf
 * https://www.geeksforgeeks.org/insertion-sort/
 * https://www.tutorialspoint.com/java/number_compareto.htm
 * https://www.tutorialspoint.com/data_structures_algorithms/shell_sort_algorithm.htm
 * https://en.wikipedia.org/wiki/Shellsort
 * https://stackoverflow.com/questions/30740413/shell-vs-hibbard-time-complexity-comparison
 * https://www.geeksforgeeks.org/collections-sort-java-examples/
 * 
 */

import java.util.Arrays;
public class SortTest {
 private static int count;
 public static void main(String args[]) {
	 long startTime, endTime, elapsedTime;
	 int size = Integer.parseInt(args[0]);

	 Integer [] a = new Integer[size];
	 Integer [] b = new Integer[size];


	 //Bubble Sort
	 for (int i = 0; i < size; i++) {
		 a[i] = b[i] = (int)(Math.random() * 100);
	 }
	// System.out.println(Arrays.toString(a));
	 count = 0;
	 startTime = System.currentTimeMillis();
	 bubblesort(a);
	 endTime = System.currentTimeMillis();
	 elapsedTime = endTime - startTime;
	 System.out.println(Arrays.toString(a));
	 System.out.println("bubblesort took "+ count + " moves to sort " + size + " items"); 
	 System.out.println("\t in : "+ elapsedTime + " millesec \n");
 
	 //Insertion Sort
	 for (int i = 0; i < size; i++) {
		 a[i] = b[i] = (int)(Math.random() * 100);
	 }
	 System.out.println(Arrays.toString(a));
	 count = 0;
	 startTime = System.currentTimeMillis();
	 insertionSort(a);
	 endTime = System.currentTimeMillis();
	 elapsedTime = endTime - startTime;
	 System.out.println(Arrays.toString(a));
	 System.out.println("insertion sort took "+ count + " moves to sort " + size + " items"); 
	 System.out.println("\t in : "+ elapsedTime + " millesec \n");
	 
	 
	 
	 //Shell Sort
	 for (int i = 0; i < size; i++) {
		 a[i] = b[i] = (int)(Math.random() * 100);
	 }
	 System.out.println(Arrays.toString(a));
	 count = 0;
	 startTime = System.currentTimeMillis();
	 shellSort(a);
	 endTime = System.currentTimeMillis();
	 elapsedTime = endTime - startTime;
	 System.out.println(Arrays.toString(a));
	 System.out.println("Shell sort took "+ count + " moves to sort "+ size + " items"); 
	 System.out.println("\t in : "+ elapsedTime + " millesec \n");	//Library Sort
	 for (int i = 0; i < size; i++) {
		 a[i] = b[i] = (int)(Math.random() * 100);
	 }
	 System.out.println(Arrays.toString(a));
	 startTime = System.currentTimeMillis();
	 Arrays.sort(a);
	 endTime = System.currentTimeMillis();
	 elapsedTime = endTime - startTime;
	 System.out.println(Arrays.toString(a));
	 System.out.println("The Library sort sorted " + size + " items"); 
	 System.out.println("\t in : "+ elapsedTime + " millesec \n");
 
	 //Quick Sort
	 for (int i = 0; i < size; i++) {
		 a[i] = b[i] = (int)(Math.random() * 100);
	 }
	 System.out.println(Arrays.toString(a));
	 count = 0;
	 startTime = System.currentTimeMillis();
	 quickSort(a, 0, a.length -1);
	 endTime = System.currentTimeMillis();
	 elapsedTime = endTime - startTime;
	 System.out.println(Arrays.toString(a));
	 System.out.println("Quick sort took "+ count + " moves to sort "+ size + " items"); 
	 System.out.println("\t in : "+ elapsedTime + " millesec \n");
	 
	 	 
	 // Reset count and array
	 count = 0;
	 for (int i = 0; i < size; i++)
		 a[i] = b[i];
	 
	 for(int i = 0; i < size; i++) {
		 System.out.print(a[i] + " ") ;
	 } 
 
}
 
 	 //BUBBLESORT
	 public static <AnyType extends Comparable<? super AnyType>>
	 void bubblesort(AnyType[] a) {
	 for (int i = 0; i < a.length; i++) {
		 for (int j = 0; j < a.length - 1; j++) {
			 if (a[j].compareTo(a[j + 1]) > 0) {
				 AnyType tmp = a[j];
				 count++;
				 a[j] = a[j + 1];
				 count++;
				 a[j + 1] = tmp;
				 count++;
				 }
		 	}
	 	}
	 }
	 
	 //INSERTIONSORT
	 public static<AnyType extends Comparable<? super AnyType>> 
	 void insertionSort(AnyType[] a) {
		 int n = a.length;
		 for(int j =1; j < n; j++ ) {
			 AnyType key = a[j];
			 int i = j -1;
			 while( i > -1 && a[i].compareTo(key) > 0) {
					 a[i + 1] = a[i];
					 i = i -1;
					 count++;
			}
			 a[i+1] =key;
			 count++;

		}
	 }
	 
	 //SHELL SORT
	 //SHELLSORT
	 public static<AnyType extends Comparable<? super AnyType>>
	 void shellSort(AnyType[] a){
		    AnyType temp;
		    int k = (int)(Math.log(a.length)/Math.log(2));
		    int gap = (int)(Math.pow(2,k)-1);

		    while (gap > 0)
		    {
		        for (int g = 0; g < gap; g++)
		        {
		            for (int d = g + gap; d < a.length; d = d + gap)
		            {
		                for (int i = d; i - gap >= 0; i = i - gap)
		                {       //compare if a[i-gap] is less than a[i]                   
		                    if (a[i - gap].compareTo(a[i]) < 0 )
		                    {
		                        break;
		                    }
		                    count++;
		                    temp = a[i];
		                    a[i] = a [i-gap];
		                    a[i-gap] = temp;

		                }
		            }
		        }

		        k = k -1;
		        gap = (int)(Math.pow(2,k)-1);
		    }
	 }	 	 //QUICK SORT
	 
	 //QUICKSORT FAMILY
	 public static int partion(Integer[] a,int left, int right)
		{
			//using first element as pivot
			int pivot = a[left];
		   	int i = left;
			//iterate through and it a[j] is less than the pivot, swap
			for(int j = left+1;j <= right;j++)
			{  
				if(a[j] < pivot)
				{
					i++;    
					swap(a,i,j);   
				}
			}
			swap(a,i,left);
			
			return i;
		}	
	 public static void quickSort(Integer[] a,int low, int high)
		{
			if(low < high)
			{ 
				//divide the array into two and quick sort them
				int p = partion(a,low,high);
				quickSort(a,low,p-1);
				count++;
				quickSort(a,p+1,high);
				count++;
			}
		}	
	 public static void swap(Integer[] a,int i, int j)
		{
			int temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
		
}
//good